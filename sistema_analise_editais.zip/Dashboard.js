import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";

const data = [
  { name: "Entrega", dias: 10 },
  { name: "Pagamento", dias: 30 },
  { name: "Aditivo", dias: 60 },
];

export default function Dashboard() {
  return (
    <div className="p-6 grid grid-cols-1 md:grid-cols-2 gap-4">
      <Card>
        <CardContent>
          <h2 className="text-xl font-semibold mb-4">Prazo de Entrega</h2>
          <p>10 dias úteis</p>
        </CardContent>
      </Card>
      <Card>
        <CardContent>
          <h2 className="text-xl font-semibold mb-4">Prazo de Pagamento</h2>
          <p>30 dias após entrega</p>
        </CardContent>
      </Card>
      <Card className="col-span-1 md:col-span-2">
        <CardContent>
          <h2 className="text-xl font-semibold mb-4">Resumo dos Prazos</h2>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={data}>
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Bar dataKey="dias" fill="#82ca9d" />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>
    </div>
  );
}
